
import React from 'react';

const ChildComponent = ({ value }) => {
  return (
    <div>
     
      <p>Value from parent: {value}</p>
    </div>
  );
};

export default ChildComponent;
