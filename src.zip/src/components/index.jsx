//
import React, { useState } from 'react';
import ChildComponent from './ChildComponent';

const MainComponent = () => {
  const [value, setValue] = useState('Initial Value');

  const handleChange = () => {
    
    setValue('New Value');
  };

  return (
    <div>
      <button onClick={handleChange}>Change Value</button>
      <ChildComponent value={value} />
    </div>
  );
};

export default MainComponent;








